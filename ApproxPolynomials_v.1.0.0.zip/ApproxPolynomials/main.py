#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
Главный модуль программы ApproxPolynomials.
Точка входа для консольного интерфейса.

Примеры запуска:
    python main.py --function runge --nodes 8 12 16 --grid uniform
    python main.py --function all --nodes 5 10 20 --grid both
    python main.py --function sin --nodes 10 --grid chebyshev --no-pdf
"""

import argparse
import os
import sys
import csv
import numpy as np
from datetime import datetime

# Добавляем корневую директорию в путь для импорта
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from interpolation import (
    LagrangePolynomial,
    NewtonPolynomial,
    LinearSpline,
    CubicSpline,
    uniform_grid,
    chebyshev_grid,
    compute_errors
)
from functions import get_test_functions, add_custom_function
from visualization import (
    plot_comparison,
    plot_error_convergence,
    plot_grid_comparison
)
from report_generator import ReportGenerator


def parse_arguments():
    """Разбор аргументов командной строки."""
    parser = argparse.ArgumentParser(
        description='ApproxPolynomials — сравнение методов интерполяции',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Примеры использования:
  python main.py --function runge --nodes 8 12 16 --grid uniform
  python main.py --function all --nodes 5 10 15 20 --grid both
  python main.py --function sin --nodes 10 --grid chebyshev
        """
    )
    
    parser.add_argument(
        '--function', '-f',
        nargs='+',
        default=['all'],
        choices=['all', 'sin', 'runge', 'abs', 'exp_sin'],
        help='Выбор функции(й) для исследования (по умолчанию: all)'
    )
    
    parser.add_argument(
        '--nodes', '-n',
        type=int,
        nargs='+',
        default=[5, 10, 15, 20],
        help='Количество узлов интерполяции (по умолчанию: 5 10 15 20)'
    )
    
    parser.add_argument(
        '--grid', '-g',
        choices=['uniform', 'chebyshev', 'both'],
        default='both',
        help='Тип сетки (по умолчанию: both)'
    )
    
    parser.add_argument(
        '--output', '-o',
        default='results',
        help='Директория для сохранения результатов (по умолчанию: results)'
    )
    
    parser.add_argument(
        '--no-pdf',
        action='store_true',
        help='Не компилировать PDF (только LaTeX и HTML)'
    )
    
    parser.add_argument(
        '--methods', '-m',
        nargs='+',
        default=['lagrange', 'newton', 'linear', 'cubic'],
        choices=['lagrange', 'newton', 'linear', 'cubic'],
        help='Методы интерполяции (по умолчанию: все)'
    )

    parser.add_argument(
        '--custom-function', '-cf',
        type=str,
        default=None,
        help='Пользовательская функция от x в виде строки, '
             'например: "sin(x)*exp(-x)" или "x**2 + cos(pi*x)"'
    )
    
    parser.add_argument(
        '--custom-interval', '-ci',
        type=float,
        nargs=2,
        default=None,
        metavar=('A', 'B'),
        help='Границы отрезка для пользовательской функции (по умолчанию: 0 1)'
    )
    
    parser.add_argument(
        '--custom-name', '-cn',
        type=str,
        default='custom_function',
        help='Имя пользовательской функции для сохранения файлов'
    )
    
    return parser.parse_args()


def create_method(name: str, x: np.ndarray, y: np.ndarray):
    """
    Фабрика для создания объектов интерполяции.
    
    Параметры:
    ----------
    name : str
        Имя метода ('lagrange', 'newton', 'linear', 'cubic').
    x, y : np.ndarray
        Узлы и значения.
    
    Возвращает:
    -----------
    Объект интерполяции или None.
    """
    methods = {
        'lagrange': LagrangePolynomial,
        'newton': NewtonPolynomial,
        'linear': LinearSpline,
        'cubic': CubicSpline
    }
    
    if name not in methods:
        return None
    
    try:
        return methods[name](x, y)
    except Exception as e:
        print(f"  Ошибка при создании {name}: {e}")
        return None


def run_analysis(args):
    """
    Основная функция анализа.
    
    Параметры:
    ----------
    args : argparse.Namespace
        Аргументы командной строки.
    """
    # Создание выходной директории
    os.makedirs(args.output, exist_ok=True)
    
    # Получение тестовых функций
    all_functions = get_test_functions()
    
    # Добавление пользовательской функции, если задана
    if args.custom_function:
        try:
            a_custom, b_custom = args.custom_interval if args.custom_interval else (0.0, 1.0)
            custom_name = args.custom_name
            
            custom_func = add_custom_function(
                args.custom_function, 
                a_custom, 
                b_custom, 
                custom_name
            )
            
            all_functions[custom_name] = custom_func
            print(f"✅ Пользовательская функция добавлена: {custom_func[4]}")
        except Exception as e:
            print(f"❌ Ошибка в пользовательской функции: {e}")
            print("   Проверьте синтаксис выражения.")
            sys.exit(1)
    
    if 'all' in args.function:
        selected_functions = list(all_functions.keys())
    elif args.custom_function and 'custom' not in args.function:
        # Если пользователь указал --custom-function, но не указал его в --function,
        # добавляем автоматически
        selected_functions = args.function + [args.custom_name]
    else:
        selected_functions = args.function
    
    
    # Определение типов сеток
    grids = []
    if args.grid in ['uniform', 'both']:
        grids.append('uniform')
    if args.grid in ['chebyshev', 'both']:
        grids.append('chebyshev')
    
    # Инициализация генератора отчёта
    report = ReportGenerator(args.output)
    report.add_section(
        "Постановка задачи",
        "Исследуется задача приближения функций с использованием различных "
        "методов интерполяции: полиномов Лагранжа и Ньютона (глобальная "
        "интерполяция), линейных и кубических сплайнов (кусочная интерполяция). "
        "Анализируется влияние выбора сетки (равномерная и Чебышёвская) "
        "на точность приближения. Рассматриваются следующие метрики качества: "
        "равномерная норма $||f - P||_\\infty$ и среднеквадратичная норма "
        "$||f - P||_2$."
    )
    
    # Словарь для хранения всех результатов
    all_errors = {}
    
    print("=" * 60)
    print("ApproxPolynomials — Анализ методов интерполяции")
    print("=" * 60)
    print(f"Функции: {', '.join(selected_functions)}")
    print(f"Узлы: {', '.join(map(str, args.nodes))}")
    print(f"Сетки: {', '.join(grids)}")
    print(f"Методы: {', '.join(args.methods)}")
    print("=" * 60)
    
    # Основной цикл по функциям
    for func_key in selected_functions:
        file_name, f, a, b, description = all_functions[func_key]
        print(f"\n{'─' * 60}")
        print(f"Функция: {description}")
        print(f"{'─' * 60}")
        
        func_errors = {method: {} for method in args.methods}
        
        # Цикл по количеству узлов
        for n_nodes in args.nodes:
            print(f"\n  Количество узлов: {n_nodes}")
            
            # Цикл по типам сеток
            for grid_type in grids:
                print(f"    Сетка: {grid_type}")
                
                # Построение сетки
                if grid_type == 'uniform':
                    nodes = uniform_grid(a, b, n_nodes)
                    grid_label = f'равномерная (n={n_nodes})'
                else:
                    nodes = chebyshev_grid(a, b, n_nodes)
                    grid_label = f'Чебышёва (n={n_nodes})'
                
                y_values = f(nodes)
                
                # Применение методов
                approximations = {}
                nodes_dict = {}
                
                for method_name in args.methods:
                    method_obj = create_method(method_name, nodes, y_values)
                    if method_obj:
                        approximations[method_name] = method_obj
                        nodes_dict[method_name] = nodes
                        
                        # Вычисление погрешностей
                        errors = compute_errors(f, method_obj, a, b)
                        
                        if n_nodes not in func_errors[method_name]:
                            func_errors[method_name][n_nodes] = {}
                        
                        func_errors[method_name][n_nodes][grid_type] = errors
                        
                        print(f"      {method_name:12s}: "
                              f"L∞ = {errors['uniform']:.4e}, "
                              f"L2 = {errors['l2']:.4e}")
                
                # Построение графика сравнения
                if approximations:
                    plot_filename = os.path.join(
                        args.output,
                        f'{file_name}_n{n_nodes}_{grid_type}'
                    )
                    
                    plot_comparison(
                        f_exact=f,
                        approximations=approximations,
                        nodes=nodes_dict,
                        a=a, b=b,
                        title=f'{description}, {grid_label}',
                        filename=plot_filename
                    )
                    
                    report.add_figure(
                        f'{file_name}_n{n_nodes}_{grid_type}.pdf',
                        f'Сравнение методов для {description}, {grid_label}',
                        width=r'0.95\textwidth'
                    )
        
        # Сохранение ошибок для анализа сходимости
        all_errors[func_key] = func_errors
        
    for grid_type in grids:
        convergence_data = {}
        for method_name in args.methods:
            convergence_data[method_name] = {}
            for n_nodes in args.nodes:
                if n_nodes in func_errors[method_name]:
                # Извлекаем данные для конкретного типа сетки
                    grid_errors = func_errors[method_name][n_nodes].get(grid_type)
                    if grid_errors:
                        convergence_data[method_name][n_nodes] = {
                            'uniform': grid_errors['uniform'],
                            'l2': grid_errors['l2']
                        }

            
            if convergence_data:
                conv_filename = os.path.join(
                    args.output,
                    f'{file_name}_convergence_{grid_type}'
                )
                grid_label = 'равномерной' if grid_type == 'uniform' else 'Чебышёва'
                
                plot_error_convergence(
                    errors=convergence_data,
                    title=f'{description}, {grid_label} сетка',
                    filename=conv_filename
                )
                
                report.add_figure(
                    f'{file_name}_convergence_{grid_type}.pdf',
                    f'Сходимость методов для {description}, {grid_label} сетка'
                )
        
        # Сравнение сеток для полиномов
        for method_name in ['lagrange', 'newton']:
            if method_name not in args.methods:
                continue
            
            n_demo = max(args.nodes)  # Демонстрация на максимальном числе узлов
            
            if 'uniform' in grids and 'chebyshev' in grids:
                # Равномерная сетка
                nodes_uniform = uniform_grid(a, b, n_demo)
                y_uniform = f(nodes_uniform)
                approx_uniform = create_method(method_name, nodes_uniform, y_uniform)
                
                # Сетка Чебышёва
                nodes_cheb = chebyshev_grid(a, b, n_demo)
                y_cheb = f(nodes_cheb)
                approx_cheb = create_method(method_name, nodes_cheb, y_cheb)
                
                if approx_uniform and approx_cheb:
                    grid_comp_filename = os.path.join(
                        args.output,
                        f'{file_name}_{method_name}_grid_comparison'
                    )
                    
                    plot_grid_comparison(
                        f_exact=f,
                        approx_uniform=approx_uniform,
                        approx_chebyshev=approx_cheb,
                        nodes_uniform=nodes_uniform,
                        nodes_chebyshev=nodes_cheb,
                        a=a, b=b,
                        method_name=method_name,
                        title=description,
                        filename=grid_comp_filename
                    )
                    
                    report.add_figure(
                        f'{file_name}_{method_name}_grid_comparison.pdf',
                        f'Сравнение сеток для метода {method_name}, {description}'
                    )
    
    # Создание таблиц для отчёта
    print(f"\n{'=' * 60}")
    print("Генерация отчёта...")
    print(f"{'=' * 60}")
    
    # Таблица результатов
    headers = ['Функция', 'Метод', 'Сетка', 'n', 'L∞', 'L2']
    rows = []
    
    for func_key in selected_functions:
        for method_name in args.methods:
            for n_nodes in args.nodes:
                for grid_type in grids:
                    if func_key in all_errors and \
                       method_name in all_errors[func_key] and \
                       n_nodes in all_errors[func_key][method_name] and \
                       grid_type in all_errors[func_key][method_name][n_nodes]:
                        
                        err = all_errors[func_key][method_name][n_nodes][grid_type]
                        rows.append([
                            func_key,
                            method_name,
                            grid_type,
                            str(n_nodes),
                            f"{err['uniform']:.4e}",
                            f"{err['l2']:.4e}"
                        ])
    
    report.add_table(
        'Результаты численного эксперимента',
        headers,
        rows
    )
    
    # Сохранение таблицы в CSV для дальнейшего анализа
    csv_path = os.path.join(args.output, 'errors_table.csv')
    with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(headers)
        writer.writerows(rows)
    print(f"Таблица погрешностей сохранена: {csv_path}")
    
    # Сохранение LaTeX и компиляция
    report.add_section(
        "Выводы",
        "Проведён сравнительный анализ методов интерполяции. "
        "Показано, что глобальная полиномиальная интерполяция (Лагранж, Ньютон) "
        "подвержена феномену Рунге на равномерных сетках, в то время как "
        "использование сетки Чебышёва значительно улучшает точность. "
        "Кусочно-полиномиальная интерполяция (сплайны) демонстрирует устойчивость "
        "на равномерных сетках и является предпочтительной для негладких функций. "
        "Кубический сплайн обеспечивает наилучший баланс между точностью и "
        "гладкостью приближения."
    )
    
    tex_path = report.save_tex('report.tex')
    report.generate_html('report.html')
    
    if not args.no_pdf:
        print("\nКомпиляция PDF-отчёта...")
        success = report.compile_pdf('report.tex')
        if not success:
            print("PDF не создан. Доступен HTML-отчёт и исходный LaTeX-файл.")
    else:
        print("\nПропуск компиляции PDF (флаг --no-pdf).")
        print(f"LaTeX-файл сохранён: {tex_path}")
    
    print(f"\n{'=' * 60}")
    print("Анализ завершён!")
    print(f"Результаты сохранены в директории: {os.path.abspath(args.output)}")
    print(f"{'=' * 60}")


def main():
    """Точка входа в программу."""
    args = parse_arguments()
    
    # Проверка наличия numpy
    try:
        import numpy as np
    except ImportError:
        print("Ошибка: требуется NumPy.")
        print("Установите зависимости: pip install -r requirements.txt")
        sys.exit(1)
    
    run_analysis(args)


if __name__ == '__main__':
    main()

