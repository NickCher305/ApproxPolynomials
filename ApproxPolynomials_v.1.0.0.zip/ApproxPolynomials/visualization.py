#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
Модуль визуализации результатов интерполяции.
Строит графики сравнения точной функции и приближений,
а также графики распределения погрешности.
"""

import matplotlib
matplotlib.use('Agg')  # Для работы без GUI-окна
import matplotlib.pyplot as plt
import numpy as np
import os
from typing import Dict, Callable


# Настройка стиля графиков в научном стиле
plt.rcParams.update({
    'figure.figsize': (12, 8),
    'figure.dpi': 150,
    'font.size': 12,
    'axes.titlesize': 14,
    'axes.labelsize': 13,
    'legend.fontsize': 11,
    'lines.linewidth': 1.8,
    'lines.markersize': 6,
    'savefig.bbox': 'tight',
    'savefig.format': 'pdf',
    'text.usetex': False,  # Не требовать LaTeX для меток
})


def plot_comparison(
    f_exact: Callable,
    approximations: Dict[str, Callable],
    nodes: Dict[str, np.ndarray],
    a: float,
    b: float,
    title: str,
    filename: str,
    n_plot: int = 1000
):
    """
    Строит график сравнения точной функции и приближений.
    
    Параметры:
    ----------
    f_exact : callable
        Точная функция.
    approximations : dict
        Словарь {имя_метода: функция_приближения}.
    nodes : dict
        Словарь {имя_метода: массив_узлов}.
    a, b : float
        Границы отрезка.
    title : str
        Заголовок графика.
    filename : str
        Имя файла для сохранения (без расширения).
    n_plot : int
        Количество точек для построения графика.
    """
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
    
    x_plot = np.linspace(a, b, n_plot)
    y_exact = f_exact(x_plot)
    
    # Верхний график: функции
    ax1.plot(x_plot, y_exact, 'k-', label='Точная функция', linewidth=2.5, zorder=1)
    
    # Фиксированное сопоставление методов и цветов
    color_map = {
        'lagrange': '#e74c3c',
        'newton': '#e67e22',
        'linear': '#2ecc71',
        'cubic': '#3498db'
    }
    
    label_map = {
        'lagrange': 'Лагранж',
        'newton': 'Ньютон',
        'linear': 'Линейный сплайн',
        'cubic': 'Кубический сплайн'
    }
    
    for name, approx in approximations.items():
        color = color_map.get(name, '#999999')
        display_name = label_map.get(name, name)
        
        ax1.plot(x_plot, approx(x_plot), '--', color=color, 
                label=display_name, zorder=2)
        
        # Отмечаем узлы интерполяции
        if name in nodes:
            n = nodes[name]
            ax1.scatter(n, f_exact(n), color=color, s=40, zorder=3, marker='o',
                       edgecolors='black', linewidths=0.5)
    
    ax1.set_xlabel('x')
    ax1.set_ylabel('f(x)')
    ax1.set_title(f'Сравнение методов интерполяции\n{title}')
    ax1.legend(loc='best')
    ax1.grid(True, alpha=0.3)
    
    # Нижний график: погрешности
    for name, approx in approximations.items():
        y_approx = approx(x_plot)
        error = np.abs(y_exact - y_approx)
        color = color_map.get(name, '#999999')
        display_name = label_map.get(name, name)
        
        ax2.semilogy(x_plot, error, color=color, 
                    label=f'{display_name} (погрешность)')
    
    ax2.set_xlabel('x')
    ax2.set_ylabel('|f(x) - P(x)|')
    ax2.set_title('Распределение абсолютной погрешности (логарифмическая шкала)')
    ax2.legend(loc='best')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'{filename}.pdf')
    plt.savefig(f'{filename}.png')
    plt.close()


def plot_error_convergence(
    errors: Dict[str, Dict[int, Dict[str, float]]],
    title: str,
    filename: str
):
    """
    Строит график сходимости методов при увеличении числа узлов.
    
    Параметры:
    ----------
    errors : dict
        Вложенный словарь:
        {имя_метода: {n_узлов: {'uniform': float, 'l2': float}}}
    title : str
        Заголовок.
    filename : str
        Имя файла для сохранения.
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    colors = ['#e74c3c', '#3498db', '#2ecc71', '#9b59b6']
    markers = ['o', 's', '^', 'D']
    
    for idx, (method_name, method_errors) in enumerate(errors.items()):
        n_values = sorted(method_errors.keys())
        uniform_errors = [method_errors[n]['uniform'] for n in n_values]
        l2_errors = [method_errors[n]['l2'] for n in n_values]
        
        color = colors[idx % len(colors)]
        marker = markers[idx % len(markers)]
        
        ax1.semilogy(n_values, uniform_errors, color=color, marker=marker,
                    label=method_name, linewidth=2, markersize=8)
        ax2.semilogy(n_values, l2_errors, color=color, marker=marker,
                    label=method_name, linewidth=2, markersize=8)
    
    ax1.set_xlabel('Количество узлов n')
    ax1.set_ylabel(r'$||f - P||_\infty$')
    ax1.set_title('Сходимость в равномерной норме')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    ax2.set_xlabel('Количество узлов n')
    ax2.set_ylabel(r'$||f - P||_2$')
    ax2.set_title('Сходимость в среднеквадратичной норме')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    fig.suptitle(f'Анализ сходимости методов\n{title}', fontsize=14)
    plt.tight_layout()
    plt.savefig(f'{filename}.pdf')
    plt.savefig(f'{filename}.png')
    plt.close()


def plot_grid_comparison(
    f_exact: Callable,
    approx_uniform: Callable,
    approx_chebyshev: Callable,
    nodes_uniform: np.ndarray,
    nodes_chebyshev: np.ndarray,
    a: float,
    b: float,
    method_name: str,
    title: str,
    filename: str,
    n_plot: int = 1000
):
    """
    Сравнение работы одного метода на равномерной и чебышёвской сетках.
    
    Параметры аналогичны plot_comparison.
    """
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
    
    x_plot = np.linspace(a, b, n_plot)
    y_exact = f_exact(x_plot)
    
    # График с равномерной сеткой
    ax1.plot(x_plot, y_exact, 'k-', label='Точная функция', linewidth=2)
    ax1.plot(x_plot, approx_uniform(x_plot), '--', color='#e74c3c', 
             label=f'{method_name} (равномерная сетка)')
    ax1.scatter(nodes_uniform, f_exact(nodes_uniform), color='#e74c3c', 
               s=30, zorder=3, edgecolors='black', linewidths=0.5)
    
    error_uniform = np.abs(y_exact - approx_uniform(x_plot))
    ax1.fill_between(x_plot, y_exact - error_uniform, y_exact + error_uniform,
                     alpha=0.2, color='#e74c3c')
    
    ax1.set_xlabel('x')
    ax1.set_ylabel('f(x)')
    ax1.set_title(f'Равномерная сетка ({len(nodes_uniform)} узлов)')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # График с чебышёвской сеткой
    ax2.plot(x_plot, y_exact, 'k-', label='Точная функция', linewidth=2)
    ax2.plot(x_plot, approx_chebyshev(x_plot), '--', color='#3498db',
             label=f'{method_name} (сетка Чебышёва)')
    ax2.scatter(nodes_chebyshev, f_exact(nodes_chebyshev), color='#3498db',
               s=30, zorder=3, edgecolors='black', linewidths=0.5)
    
    error_cheb = np.abs(y_exact - approx_chebyshev(x_plot))
    ax2.fill_between(x_plot, y_exact - error_cheb, y_exact + error_cheb,
                     alpha=0.2, color='#3498db')
    
    ax2.set_xlabel('x')
    ax2.set_ylabel('f(x)')
    ax2.set_title(f'Сетка Чебышёва ({len(nodes_chebyshev)} узлов)')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    fig.suptitle(f'Влияние выбора сетки: {method_name}\n{title}', fontsize=14)
    plt.tight_layout()
    plt.savefig(f'{filename}.pdf')
    plt.savefig(f'{filename}.png')
    plt.close()

