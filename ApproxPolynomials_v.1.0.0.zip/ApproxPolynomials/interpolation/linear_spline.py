#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
Линейный сплайн — кусочно-линейная интерполяция.
Простейший сплайн первого порядка.
"""

import numpy as np


class LinearSpline:
    """
    Линейный сплайн (сплайн степени 1, дефекта 1).
    
    На каждом отрезке [x_i, x_{i+1}] приближает функцию прямой линией:
        S(x) = y_i + (y_{i+1} - y_i) * (x - x_i) / (x_{i+1} - x_i)
    
    Атрибуты:
    ---------
    nodes : np.ndarray
        Узлы сплайна.
    values : np.ndarray
        Значения в узлах.
    slopes : np.ndarray
        Коэффициенты наклона для каждого отрезка.
    """
    
    def __init__(self, x: np.ndarray, y: np.ndarray):
        """
        Построение линейного сплайна.
        
        Параметры:
        ----------
        x : np.ndarray
            Узлы интерполяции (строго возрастающие).
        y : np.ndarray
            Значения функции в узлах.
        """
        if len(x) != len(y):
            raise ValueError("Массивы узлов и значений должны иметь одинаковую длину")
        
        # Проверка на возрастание
        if np.any(np.diff(x) <= 0):
            raise ValueError("Узлы должны быть строго возрастающими")
        
        self.nodes = np.asarray(x, dtype=float)
        self.values = np.asarray(y, dtype=float)
        self.n = len(x)
        
        # Вычисление угловых коэффициентов для каждого отрезка
        self.slopes = np.diff(self.values) / np.diff(self.nodes)
    
    def __call__(self, x: np.ndarray) -> np.ndarray:
        """
        Вычисление значений линейного сплайна.
        
        Использует np.searchsorted для определения нужного отрезка.
        
        Параметры:
        ----------
        x : np.ndarray или float
            Точки для вычисления.
        
        Возвращает:
        -----------
        np.ndarray или float
            Значения сплайна.
        """
        x = np.asarray(x, dtype=float)
        scalar_input = x.ndim == 0
        x = np.atleast_1d(x)
        
        # Для каждой точки находим индекс отрезка
        # searchsorted возвращает индекс правого конца отрезка
        indices = np.searchsorted(self.nodes, x, side='right') - 1
        
        # Обработка граничных случаев
        indices = np.clip(indices, 0, self.n - 2)
        
        # Линейная интерполяция
        result = self.values[indices] + self.slopes[indices] * (x - self.nodes[indices])
        
        return result[0] if scalar_input else result

