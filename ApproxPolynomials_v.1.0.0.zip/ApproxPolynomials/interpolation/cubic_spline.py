#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
Кубический сплайн с естественными граничными условиями.
Построение через решение трёхдиагональной СЛАУ методом прогонки.
"""

import numpy as np
from .tridiagonal import solve_tridiagonal


class CubicSpline:
    """
    Кубический сплайн (сплайн степени 3, дефекта 1).
    
    Использует естественные граничные условия: S''(a) = S''(b) = 0.
    Построен на основе моментов (вторых производных).
    
    Атрибуты:
    ---------
    nodes : np.ndarray
        Узлы сплайна.
    values : np.ndarray
        Значения в узлах.
    moments : np.ndarray
        Вторые производные в узлах (M_i).
    h : np.ndarray
        Шаги сетки.
    """
    
    def __init__(self, x: np.ndarray, y: np.ndarray):
        """
        Построение кубического сплайна.
        
        Параметры:
        ----------
        x : np.ndarray
            Узлы интерполяции (строго возрастающие).
        y : np.ndarray
            Значения функции в узлах.
        """
        if len(x) != len(y):
            raise ValueError("Массивы узлов и значений должны иметь одинаковую длину")
        
        if len(x) < 3:
            raise ValueError("Для кубического сплайна нужно минимум 3 узла")
        
        if np.any(np.diff(x) <= 0):
            raise ValueError("Узлы должны быть строго возрастающими")
        
        self.nodes = np.asarray(x, dtype=float)
        self.values = np.asarray(y, dtype=float)
        self.n = len(x)
        self.h = np.diff(self.nodes)  # Шаги сетки
        
        # Построение и решение СЛАУ для моментов
        self._compute_moments()
    
    def _compute_moments(self):
        """
        Вычисление моментов M_i = S''(x_i) из трёхдиагональной СЛАУ.
        
        Система для естественного сплайна (M_0 = M_{n-1} = 0):
        h_{i-1}*M_{i-1} + 2*(h_{i-1}+h_i)*M_i + h_i*M_{i+1} = 
            6*((y_{i+1}-y_i)/h_i - (y_i-y_{i-1})/h_{i-1})
        """
        # Количество внутренних узлов (без граничных)
        m = self.n - 2
        
        if m == 0:
            self.moments = np.zeros(2)
            return
        
        # Формирование трёхдиагональной системы
        a = np.zeros(self.n)  # Поддиагональ
        b = np.zeros(self.n)  # Главная диагональ
        c = np.zeros(self.n)  # Наддиагональ
        d = np.zeros(self.n)  # Правая часть
        
        # Граничные условия: M_0 = 0, M_{n-1} = 0
        b[0] = 1.0
        d[0] = 0.0
        
        b[self.n - 1] = 1.0
        d[self.n - 1] = 0.0
        
        # Уравнения для внутренних узлов
        for i in range(1, self.n - 1):
            h_prev = self.h[i - 1]
            h_curr = self.h[i]
            
            a[i] = h_prev
            b[i] = 2.0 * (h_prev + h_curr)
            c[i] = h_curr
            
            # Правая часть: 6 * (f[x_i, x_{i+1}] - f[x_{i-1}, x_i])
            d[i] = 6.0 * ((self.values[i+1] - self.values[i]) / h_curr - 
                          (self.values[i] - self.values[i-1]) / h_prev)
        
        # Решение методом прогонки
        self.moments = solve_tridiagonal(a, b, c, d)
    
    def __call__(self, x: np.ndarray) -> np.ndarray:
        """
        Вычисление значений кубического сплайна.
        
        На отрезке [x_i, x_{i+1}]:
            S(x) = M_i*(x_{i+1}-x)^3/(6h_i) + M_{i+1}*(x-x_i)^3/(6h_i) +
                   (y_i - M_i*h_i^2/6)*(x_{i+1}-x)/h_i + 
                   (y_{i+1} - M_{i+1}*h_i^2/6)*(x-x_i)/h_i
        
        Параметры:
        ----------
        x : np.ndarray или float
            Точки для вычисления.
        
        Возвращает:
        -----------
        np.ndarray или float
            Значения сплайна.
        """
        x = np.asarray(x, dtype=float)
        scalar_input = x.ndim == 0
        x = np.atleast_1d(x)
        
        indices = np.searchsorted(self.nodes, x, side='right') - 1
        indices = np.clip(indices, 0, self.n - 2)
        
        result = np.zeros_like(x, dtype=float)
        
        for idx in range(len(x)):
            i = indices[idx]
            xi = x[idx]
            
            h_i = self.h[i]
            M_i = self.moments[i]
            M_ip1 = self.moments[i + 1]
            y_i = self.values[i]
            y_ip1 = self.values[i + 1]
            
            # Вычисление по формуле кубического сплайна
            term1 = M_i * (self.nodes[i+1] - xi)**3 / (6.0 * h_i)
            term2 = M_ip1 * (xi - self.nodes[i])**3 / (6.0 * h_i)
            term3 = (y_i - M_i * h_i**2 / 6.0) * (self.nodes[i+1] - xi) / h_i
            term4 = (y_ip1 - M_ip1 * h_i**2 / 6.0) * (xi - self.nodes[i]) / h_i
            
            result[idx] = term1 + term2 + term3 + term4
        
        return result[0] if scalar_input else result

