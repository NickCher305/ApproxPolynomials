#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
Полином Лагранжа в барицентрической форме.
Обеспечивает численную устойчивость по сравнению с канонической формой.
"""

import numpy as np


class LagrangePolynomial:
    """
    Интерполяционный полином Лагранжа.
    
    Использует первую барицентрическую формулу для вычисления значений.
    Это обеспечивает вычислительную устойчивость O(n^2) и позволяет
    избежать проблем с переполнением при большом количестве узлов.
    
    Атрибуты:
    ---------
    nodes : np.ndarray
        Узлы интерполяции.
    values : np.ndarray
        Значения функции в узлах.
    weights : np.ndarray
        Барицентрические веса.
    """
    
    def __init__(self, x: np.ndarray, y: np.ndarray):
        """
        Построение полинома Лагранжа по узлам и значениям.
        
        Параметры:
        ----------
        x : np.ndarray
            Узлы интерполяции.
        y : np.ndarray
            Значения функции в узлах.
        """
        if len(x) != len(y):
            raise ValueError("Массивы узлов и значений должны иметь одинаковую длину")
        
        self.nodes = np.asarray(x, dtype=float)
        self.values = np.asarray(y, dtype=float)
        self.n = len(x)
        
        # Вычисление барицентрических весов
        self._compute_weights()
    
    def _compute_weights(self):
        """
        Вычисление барицентрических весов w_j.
        
        w_j = 1 / ∏_{k≠j} (x_j - x_k)
        
        Для устойчивости используется формула с попарным перемножением.
        """
        self.weights = np.ones(self.n)
        
        for j in range(self.n):
            for k in range(self.n):
                if k != j:
                    self.weights[j] /= (self.nodes[j] - self.nodes[k])
    
    def __call__(self, x: np.ndarray) -> np.ndarray:
        """
        Вычисление значений полинома Лагранжа в точках x.
        
        Используется первая барицентрическая формула:
            P(x) = Σ w_j * y_j / (x - x_j) / Σ w_j / (x - x_j)
        
        Параметры:
        ----------
        x : np.ndarray или float
            Точки, в которых нужно вычислить полином.
        
        Возвращает:
        -----------
        np.ndarray или float
            Значения полинома в заданных точках.
        """
        x = np.asarray(x, dtype=float)
        scalar_input = x.ndim == 0
        x = np.atleast_1d(x)
        
        result = np.zeros_like(x, dtype=float)
        
        for i, xi in enumerate(x):
            # Проверка: если x совпадает с узлом — возвращаем точное значение
            idx = np.where(np.abs(xi - self.nodes) < 1e-14)[0]
            if len(idx) > 0:
                result[i] = self.values[idx[0]]
                continue
            
            # Барицентрическая формула
            terms = self.weights / (xi - self.nodes)
            numerator = np.sum(terms * self.values)
            denominator = np.sum(terms)
            
            if abs(denominator) < 1e-15:
                result[i] = 0.0  # Защита от деления на ноль
            else:
                result[i] = numerator / denominator
        
        return result[0] if scalar_input else result
    
    def get_coefficients(self) -> np.ndarray:
        """
        Возвращает коэффициенты полинома в канонической форме.
        Используется для аналитических целей (может быть неустойчиво).
        """
        # Строим СЛАУ Вандермонда и решаем (для справки)
        V = np.vander(self.nodes, increasing=True)
        return np.linalg.solve(V, self.values)

