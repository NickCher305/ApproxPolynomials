#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
Вспомогательные функции: построение сеток и вычисление погрешностей.
"""

import numpy as np


def uniform_grid(a: float, b: float, n: int) -> np.ndarray:
    """
    Построение равномерной сетки на отрезке [a, b].
    
    Параметры:
    ----------
    a, b : float
        Границы отрезка.
    n : int
        Количество узлов (включая концы).
    
    Возвращает:
    -----------
    np.ndarray
        Массив узлов сетки.
    """
    return np.linspace(a, b, n)


def chebyshev_grid(a: float, b: float, n: int) -> np.ndarray:
    """
    Построение сетки с узлами Чебышёва на отрезке [a, b].
    
    Узлы Чебышёва минимизируют феномен Рунге путём сгущения к краям отрезка.
    Результат всегда отсортирован по возрастанию.
    
    Параметры:
    ----------
    a, b : float
        Границы отрезка.
    n : int
        Количество узлов.
    
    Возвращает:
    -----------
    np.ndarray
        Массив узлов сетки, отсортированный по возрастанию.
    """
    # Узлы Чебышёва на [-1, 1] (в порядке убывания)
    k = np.arange(1, n + 1)
    cheb = np.cos((2 * k - 1) * np.pi / (2 * n))
    # Линейное отображение на [a, b]
    result = 0.5 * (a + b) + 0.5 * (b - a) * cheb
    # Сортировка по возрастанию (обязательно для сплайнов!)
    return np.sort(result)


def uniform_norm(f_exact: callable, f_approx: callable, a: float, b: float, 
                 n_plot: int = 1000) -> float:
    """
    Вычисление равномерной (Чебышёвской) нормы погрешности.
    
    ||f - p||_∞ ≈ max|f(x_i) - p(x_i)| на мелкой сетке.
    
    Параметры:
    ----------
    f_exact : callable
        Точная функция.
    f_approx : callable
        Приближающая функция.
    a, b : float
        Границы отрезка.
    n_plot : int
        Количество точек для оценки максимума.
    
    Возвращает:
    -----------
    float
        Значение равномерной нормы погрешности.
    """
    x = np.linspace(a, b, n_plot)
    error = np.abs(f_exact(x) - f_approx(x))
    return np.max(error)


def l2_norm(f_exact: callable, f_approx: callable, a: float, b: float,
            n_plot: int = 1000) -> float:
    """
    Вычисление среднеквадратичной (L2) нормы погрешности.
    
    ||f - p||_2 ≈ sqrt(∫_a^b (f-p)^2 dx) —  составная формула трапеций.
    
    Параметры:
    ----------
    f_exact : callable
        Точная функция.
    f_approx : callable
        Приближающая функция.
    a, b : float
        Границы отрезка.
    n_plot : int
        Количество подинтервалов для численного интегрирования.
    
    Возвращает:
    -----------
    float
        Значение среднеквадратичной нормы погрешности.
    """
    x = np.linspace(a, b, n_plot)
    dx = (b - a) / (n_plot - 1)
    error_sq = (f_exact(x) - f_approx(x)) ** 2
    # Составная формула трапеций
    integral = np.sum(error_sq) - 0.5 * (error_sq[0] + error_sq[-1])
    integral *= dx
    return np.sqrt(integral)


def compute_errors(f_exact: callable, f_approx: callable, a: float, b: float,
                   n_plot: int = 1000) -> dict:
    """
    Вычисление обеих норм погрешности.
    
    Возвращает:
    -----------
    dict
        Словарь с ключами 'uniform' и 'l2'.
    """
    return {
        'uniform': uniform_norm(f_exact, f_approx, a, b, n_plot),
        'l2': l2_norm(f_exact, f_approx, a, b, n_plot)
    }

