#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
Метод прогонки (алгоритм Томаса) для решения трёхдиагональных СЛАУ.
Используется при построении кубического сплайна.
"""

import numpy as np


def solve_tridiagonal(a: np.ndarray, b: np.ndarray, c: np.ndarray, 
                      d: np.ndarray) -> np.ndarray:
    """
    Решение системы с трёхдиагональной матрицей методом прогонки.
    
    Система имеет вид:
        b[0]*x[0] + c[0]*x[1]               = d[0]
        a[i]*x[i-1] + b[i]*x[i] + c[i]*x[i+1] = d[i]   для i = 1..n-2
        a[n-1]*x[n-2] + b[n-1]*x[n-1]       = d[n-1]
    
    Параметры:
    ----------
    a : np.ndarray
        Поддиагональ (длина n-1, a[0] не используется).
    b : np.ndarray
        Главная диагональ (длина n).
    c : np.ndarray
        Наддиагональ (длина n-1, c[n-1] не используется).
    d : np.ndarray
        Правая часть (длина n).
    
    Возвращает:
    -----------
    np.ndarray
        Вектор решения x длины n.
    
    Исключения:
    -----------
    ValueError
        Если матрица вырождена (диагональное преобладание не выполнено).
    """
    n = len(b)
    
    # Проверка размерностей
    if len(a) != n or len(c) != n or len(d) != n:
        raise ValueError("Несоответствие размерностей векторов")
    
    # Рабочие копии для преобразования
    b_copy = b.copy().astype(float)
    d_copy = d.copy().astype(float)
    
    # Прямой ход прогонки
    for i in range(1, n):
        if abs(b_copy[i-1]) < 1e-15:
            raise ValueError(f"Матрица вырождена: нулевой ведущий элемент на шаге {i-1}")
        
        m = a[i] / b_copy[i-1]
        b_copy[i] -= m * c[i-1]
        d_copy[i] -= m * d_copy[i-1]
    
    # Обратный ход прогонки
    x = np.zeros(n)
    if abs(b_copy[-1]) < 1e-15:
        raise ValueError("Матрица вырождена: нулевой последний диагональный элемент")
    
    x[-1] = d_copy[-1] / b_copy[-1]
    
    for i in range(n - 2, -1, -1):
        x[i] = (d_copy[i] - c[i] * x[i+1]) / b_copy[i]
    
    return x

