#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
Пакет interpolation содержит реализации методов приближения функций:
- Полином Лагранжа (барицентрическая форма)
- Полином Ньютона (с разделёнными разностями)
- Линейный сплайн
- Кубический сплайн (с методом прогонки)
"""

from .lagrange import LagrangePolynomial
from .newton import NewtonPolynomial
from .linear_spline import LinearSpline
from .cubic_spline import CubicSpline
from .utils import uniform_grid, chebyshev_grid, compute_errors

__all__ = [
    "LagrangePolynomial",
    "NewtonPolynomial", 
    "LinearSpline",
    "CubicSpline",
    "uniform_grid",
    "chebyshev_grid",
    "compute_errors"
]

