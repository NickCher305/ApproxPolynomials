#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
Полином Ньютона с разделёнными разностями.
Позволяет эффективно добавлять новые узлы без пересчёта всего полинома.
"""

import numpy as np


class NewtonPolynomial:
    """
    Интерполяционный полином Ньютона.
    
    Хранит таблицу разделённых разностей и вычисляет значения
    по схеме, аналогичной схеме Горнера.
    
    Атрибуты:
    ---------
    nodes : np.ndarray
        Узлы интерполяции.
    coeffs : np.ndarray
        Коэффициенты разделённых разностей f[x_0], f[x_0,x_1], ...
    """
    
    def __init__(self, x: np.ndarray, y: np.ndarray):
        """
        Построение полинома Ньютона.
        
        Параметры:
        ----------
        x : np.ndarray
            Узлы интерполяции.
        y : np.ndarray
            Значения функции в узлах.
        """
        if len(x) != len(y):
            raise ValueError("Массивы узлов и значений должны иметь одинаковую длину")
        
        self.nodes = np.asarray(x, dtype=float)
        self.n = len(x)
        
        # Вычисление таблицы разделённых разностей
        self._compute_divided_differences(np.asarray(y, dtype=float))
    
    def _compute_divided_differences(self, y: np.ndarray):
        """
        Построение таблицы разделённых разностей.
        
        Используется алгоритм с одним массивом для экономии памяти.
        На выходе y содержит диагональ таблицы — коэффициенты полинома Ньютона.
        """
        self.coeffs = y.copy()
        
        for j in range(1, self.n):
            for i in range(self.n - 1, j - 1, -1):
                self.coeffs[i] = (self.coeffs[i] - self.coeffs[i-1]) / \
                                 (self.nodes[i] - self.nodes[i-j])
    
    def __call__(self, x: np.ndarray) -> np.ndarray:
        """
        Вычисление значений полинома Ньютона по схеме Горнера.
        
        P(x) = c_0 + (x-x_0)[c_1 + (x-x_1)[c_2 + ...]]
        
        Параметры:
        ----------
        x : np.ndarray или float
            Точки для вычисления.
        
        Возвращает:
        -----------
        np.ndarray или float
            Значения полинома.
        """
        x = np.asarray(x, dtype=float)
        scalar_input = x.ndim == 0
        x = np.atleast_1d(x)
        
        result = np.full_like(x, self.coeffs[-1], dtype=float)
        
        for i in range(self.n - 2, -1, -1):
            result = self.coeffs[i] + (x - self.nodes[i]) * result
        
        return result[0] if scalar_input else result
    
    def add_node(self, x_new: float, y_new: float):
        """
        Добавление нового узла интерполяции (без полного пересчёта).
        
        Параметры:
        ----------
        x_new : float
            Новый узел.
        y_new : float
            Значение функции в новом узле.
        """
        self.nodes = np.append(self.nodes, x_new)
        self.n += 1
        
        # Вычисляем новую разделённую разность
        new_coeff = y_new
        for i in range(self.n - 1):
            new_coeff = (new_coeff - self.coeffs[i]) / (x_new - self.nodes[i])
        
        self.coeffs = np.append(self.coeffs, new_coeff)

