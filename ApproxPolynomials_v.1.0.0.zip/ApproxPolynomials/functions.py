#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
Определения тестовых функций и их производных (при необходимости).
Каждая функция возвращает: (имя, f, a, b, описание)
"""

import numpy as np


def get_test_functions():
    """
    Возвращает словарь тестовых функций.
    
    Каждая функция описывается кортежем:
        (имя_для_файла, функция, левая_граница, правая_граница, описание_на_русском)
    """
    functions = {
        'sin': (
            'sin_x',
            lambda x: np.sin(x),
            0.0,
            2.0 * np.pi,
            r'$f(x)=\sin x$ на $[0, 2\pi]$ — гладкая периодическая функция'
        ),
        'runge': (
            'runge',
            lambda x: 1.0 / (1.0 + 25.0 * x**2),
            -1.0,
            1.0,
            r'$f(x)=\frac{1}{1+25x^2}$ на $[-1, 1]$ — функция Рунге'
        ),
        'abs': (
            'abs_x',
            lambda x: np.abs(x),
            -1.0,
            1.0,
            r'$f(x)=|x|$ на $[-1, 1]$ — функция с изломом'
        ),
        'exp_sin': (
            'exp_sin',
            lambda x: np.exp(-x) * np.sin(5.0 * x),
            0.0,
            2.0,
            r'$f(x)=e^{-x}\sin(5x)$ на $[0, 2]$ — затухающие колебания'
        )
    }
    return functions

def parse_custom_function(func_str: str):
    """
    Преобразует строковое представление функции в вызываемый объект.
    
    Поддерживаемые функции: sin, cos, tan, exp, log, sqrt, abs, pi, e
    Пример: "sin(x) + cos(2*x)", "exp(-x) * x**2", "abs(x)"
    
    Параметры:
    ----------
    func_str : str
        Строка с выражением функции от x.
    
    Возвращает:
    -----------
    callable
        Функция f(x).
    
    Исключения:
    -----------
    ValueError
        Если строка содержит недопустимые конструкции.
    """
    import re
    
    # Создаём безопасное окружение для eval
    safe_names = {
        'x': None,  # Будет переопределено в лямбде
        'sin': np.sin,
        'cos': np.cos,
        'tan': np.tan,
        'exp': np.exp,
        'log': np.log,
        'sqrt': np.sqrt,
        'abs': np.abs,
        'pi': np.pi,
        'e': np.e,
        'sinh': np.sinh,
        'cosh': np.cosh,
        'tanh': np.tanh,
        'arcsin': np.arcsin,
        'arccos': np.arccos,
        'arctan': np.arctan,
        'log10': np.log10,
        'log2': np.log2,
        'power': np.power,
    }
    
    # Проверка на недопустимые символы (защита от инъекций)
    allowed_pattern = r'^[x0-9+\-*/().,\s\^a-z_]+$'
    if not re.match(allowed_pattern, func_str, re.IGNORECASE):
        raise ValueError(
            f"Выражение содержит недопустимые символы. "
            f"Разрешены: x, цифры, операторы (+, -, *, /, **, ^), "
            f"скобки, пробелы, математические функции"
        )
    
    # Заменяем ^ на ** (возведение в степень)
    func_str = func_str.replace('^', '**')
    
    # Проверяем, что выражение можно вычислить
    try:
        # Пробное вычисление в нескольких точках
        test_x = np.array([0.0, 0.5, 1.0])
        namespace = safe_names.copy()
        namespace['x'] = test_x
        test_result = eval(func_str, {"__builtins__": {}}, namespace)
    except SyntaxError as e:
        raise ValueError(f"Синтаксическая ошибка в выражении: {e}")
    except Exception as e:
        raise ValueError(f"Ошибка при вычислении выражения: {e}")
    
    # Создаём функцию
    def custom_function(x):
        namespace = safe_names.copy()
        namespace['x'] = np.asarray(x, dtype=float)
        try:
            result = eval(func_str, {"__builtins__": {}}, namespace)
            return np.asarray(result, dtype=float)
        except Exception as e:
            raise ValueError(f"Ошибка при вычислении функции: {e}")
    
    return custom_function, func_str


def add_custom_function(func_str: str, a: float, b: float, name: str = "custom"):
    """
    Создаёт запись для пользовательской функции в формате, совместимом с get_test_functions().
    
    Параметры:
    ----------
    func_str : str
        Строка с выражением функции от x.
    a, b : float
        Границы отрезка.
    name : str
        Имя функции для файлов и отчётов.
    
    Возвращает:
    -----------
    tuple
        (имя_файла, функция, a, b, описание)
    """
    f, clean_str = parse_custom_function(func_str)
    
    # Формируем LaTeX-описание
    latex_str = clean_str.replace('*', r'\cdot ').replace('**', '^')
    description = f"$f(x)={latex_str}$ на $[{a}, {b}]$ — пользовательская функция"
    
    return (name, f, a, b, description)